package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import bean.Flight;

public class FlightDao {
	
	public static Connection connectMe() { 
		Connection conn = null;
		try {
//loading driver and connecting to database
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/com.moshfiqrony", "root", "");
		} catch (Exception e) {
			System.out.println(e);
		}
//returning the connection
		return conn;
	}
	
	public static int insertMe(Flight obj) {
		int status = 0;
		Connection conn = FlightDao.connectMe();
		try {
			PreparedStatement ps = conn.prepareStatement("insert into schedule(planeName, fromLoc, toLoc, depDate, depTime, retDate, retTime, seat) values (?, ?, ?, ?, ?, ?, ?, ?)");
			ps.setString(1, obj.getFlightNumber());
			ps.setInt(2, obj.getFrom());
			ps.setInt(3, obj.getTo());
			ps.setDate(4, obj.getDepDate());
			ps.setTime(5, obj.getDepTime());
			ps.setDate(6, obj.getRetDate());
			ps.setTime(7, obj.getRetTime());
			ps.setInt(8, obj.getTotalSeat());
			status = ps.executeUpdate();
			conn.close();
		} catch (SQLException e) {
			System.out.println(e);
		}
		return status;
	}
	
	public static int delete(int id){  
	    int status=0;  
	    try{  
	        Connection conn = connectMe();  
	        PreparedStatement ps=conn.prepareStatement("delete from schedule where id=?");  
	        ps.setInt(1,id);  
	        status=ps.executeUpdate();  
	    }catch(Exception e){System.out.println(e);}  
	  
	    return status;  
	}  
}
